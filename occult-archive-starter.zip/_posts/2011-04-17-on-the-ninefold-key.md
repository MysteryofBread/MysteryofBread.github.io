---
title: "On the Ninefold Key"
date: 2011-04-17 23:40:00 +0300
diegetic_date: "Anno 1889, Michaelmas"
category: dossier
tags: [rituals, keys, orders]
source: "Journal of A. Corvinus, Vol. II"
provenance: "Hanna Estate, Lot 17"
location: "Trieste"
status: fragment
transcriber: "The Curator"
scan: /scans/ninefold_key_page1.jpg
excerpt: "A partial transcription concerning a key whose wards correspond to the nine letters of an unspeakable Name."
---
> *Clavis novem litterarum* — nine wards, nine intonations. Within the margin appears a sigil resembling the letter **kaf**, though reversed, and annotated in a later hand: “<em>Non aperias nisi ieiuno</em>.”

The fragment’s Latin is crude but pointed: each ward pairs to a virtue’s privation. The “final” ward is not a shape but an omission—a deliberate void in the matrix.