---
title: "Field Note: Coffeehouse in the Bazaar"
date: 2011-04-12 10:12:00 +0300
diegetic_date: "Sha'ban 1306 AH"
category: fieldnote
tags: [islamicate, manuscript, gossip]
source: "Letter to M."
provenance: "Box 4, Misc."
location: "Smyrna"
status: complete
transcriber: "The Curator"
excerpt: "A scrap about a bookseller who binds amulets into commonplace books."
---
At the third stall from the fountain, a bookseller binds **hizb** pages into ordinary ledgers, thread dyed with walnut hull. Between accounts, a prayer; between debts, a charm. He smiles thinly when asked about the **khātam**.