---
title: "Artifact: Brass Seal (Sable Order)"
date: 2011-03-12 08:05:00 +0300
diegetic_date: "1891"
category: artifact
tags: [orders, sigil, brass]
source: "Estate Catalogue"
provenance: "Lot 9"
location: "Vienna"
status: catalogued
transcriber: "The Curator"
excerpt: "A brass seal with a reversed inscription and a wolf rampant."
---
![Brass seal impression](/scans/sable_seal.jpg)

*Legend (reversed)*: `Sodalitas Nigrans`. The wolf is engraved shallowly; resin residue indicates repeated casting from wax impressions.