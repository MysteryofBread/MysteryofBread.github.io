# Bibliotheca Occulta — Jekyll Starter (2008–2012 vibe)

This is a ready-to-upload starter for an in-universe occult/esoteric/historical archive.
Upload everything in this folder to your `USERNAME.github.io` repository on GitHub.

## Quick start
1. Create a repo named `USERNAME.github.io` (replace USERNAME).
2. Upload the contents of this zip to that repo.
3. Wait 30–60 seconds and visit `https://USERNAME.github.io`.

## Where to edit
- `_config.yml` — site title/description.
- `assets/css/theme.css` — fonts, colors, layout.
- `_posts/` — your posts (Markdown). File name format: `YYYY-MM-DD-title.md`.
- `scans/` — images of pages, artifacts, plates.
- `_includes/sidebar.html` — navigation links.
- `archive/` and `tags/` — archive and tags landing pages.

No plugins required. Compatible with GitHub Pages.