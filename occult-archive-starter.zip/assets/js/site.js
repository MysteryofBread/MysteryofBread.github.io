// reserved for lightbox/search later; intentionally minimal for 2010s vibe
